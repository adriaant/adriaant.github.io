/*
	Created by Adriaan Tijsseling on 02/11/06.
	Copyright 2006 Adriaan Tijsseling. All rights reserved.
	Markdown formatter for ecto. 
*/

#import "Markdown.h"

@implementation Markdown

// Your formatter's key. Make it unique. Will show up as name in various menus.
- (NSString *)formatterKey
{
	return @"Markdown";
}

// Your formatter's description. Explain what it does. Will be shown to users in formatters list.
- (NSString *)formatterDescription
{
	return NSLocalizedStringFromTable(@"Markdown formatter for blog entries that specify Markdown format.", @"Markdown", @"Description");
}

// Given a format string (textile, markdown, or even '1' - as returned by Drupal), 
// return whether you can handle this format type.
- (BOOL)willHandleFormat:(NSString*)str
{
	NSRange rng = [str rangeOfString:@"Markdown" options:NSCaseInsensitiveSearch];
	if ( rng.location != NSNotFound ) return YES;

	return NO;
}

// Indicate if the HTML can be edited. If the source is Textile or Markdown, return NO.
- (BOOL)allowsHTMLEditing
{
	return NO;
}

// The formatting routine
- (NSString*)formatText:(NSString*)source
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];

	NSBundle		*thisBundle = [NSBundle bundleForClass:[self class]];
	NSTask			*task = [[NSTask alloc] init];
	NSPipe			*inPipe = [[NSPipe alloc] init],
					*outPipe = [[NSPipe alloc] init];
	NSFileHandle	*writingHandle = nil;
	NSMutableString	*convertedText = [[NSMutableString alloc] initWithString:@""];
	NSString		*scriptPath = [thisBundle pathForResource:@"markdown" ofType:@"perl"];
	NSString		*includePath = [NSString stringWithFormat:@"-I%@", [scriptPath stringByDeletingLastPathComponent]];
	
	[task setLaunchPath:@"/usr/bin/perl"];
	[task setStandardOutput:outPipe];
	[task setStandardInput:inPipe];
	[task setStandardError:[NSFileHandle fileHandleForWritingAtPath:@"/dev/null"]];
	[task setArguments:[NSArray arrayWithObjects:includePath, scriptPath, nil]];

	[task launch];

	writingHandle = [inPipe fileHandleForWriting];
	[writingHandle writeData:[source dataUsingEncoding:NSUTF8StringEncoding]];
	[writingHandle closeFile];

	while ( [task isRunning] )
	{
		NSData *data = [[[task standardOutput] fileHandleForReading] availableData];
		if ( data != nil && [data length] > 0 )
		{
			NSString *tmpStr = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
			if ( tmpStr != nil )
			{
				[convertedText appendString:tmpStr];
				[tmpStr release];
			}
		}
	}
	
	[task terminate];
	[task release];
	[inPipe release];
	[outPipe release];
	
	[pool release];
	return [convertedText autorelease];
}

// Custom template for a URL. Return nil for default. Placeholders are $text$, $title$, and $url$, for text, title, and link, respectively.
- (NSString*)urlTemplate
{
	return @"[$text$]($url$)";
}

@end
