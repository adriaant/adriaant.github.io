/*
	Created by Adriaan Tijsseling on 02/11/06.
	Copyright 2006 Adriaan Tijsseling. All rights reserved.
	Markdown formatter for ecto. 
*/

#import <Cocoa/Cocoa.h>
#import "FormatterInterface.h"

@interface Markdown : NSObject <ECTOFormatterProtocol>
{

}

@end
