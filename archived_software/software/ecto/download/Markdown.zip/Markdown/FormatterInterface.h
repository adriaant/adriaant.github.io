/*
	Protocol for an ecto formatter. These methods should be implemented by the plugin.

	To save defaults, use the NSUserDefaultsController. Prefix your defaults with your plugin name. i.e.
	myplugin_someSetting
*/

#import <Cocoa/Cocoa.h>

@protocol ECTOFormatterProtocol

// Your formatter's key. Make it unique. Will show up as name in various menus.
- (NSString*)formatterKey;

// Your formatter's description. Explain what it does. Will be shown to users in formatters list.
- (NSString*)formatterDescription;

// Given a format string (textile, markdown, or even '1' - as returned by Drupal), 
// return whether you can handle this format type.
- (BOOL)willHandleFormat:(NSString*)str;

// Indicate if the HTML can be edited. If the source is Textile or Markdown, return NO.
- (BOOL)allowsHTMLEditing;

// The formatting routine
- (NSString*)formatText:(NSString*)source;

// Custom template for a URL. Return nil for default. Placeholders are %text%, %title%, and %url%, for text, title, and link, respectively.
- (NSString*)urlTemplate;

@end
