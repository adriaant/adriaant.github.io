#import <Cocoa/Cocoa.h>

@interface TunesView : NSView
{
}
@end
