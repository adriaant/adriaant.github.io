/*
	Copyright 2008 Adriaan Tijsseling, All rights reserved.
	iTunes addon for ecto. 
*/

#import <Cocoa/Cocoa.h>
#import "AddonInterface.h"

@interface NSMutableString (Utils)
- (void)stripHashes:(NSString*)hash;
@end

@interface Tunes : NSObject <ECTOAddonProtocol>
{
	IBOutlet id	prefsView;
	IBOutlet id	textView;
}

- (IBAction)revert:(id)sender;
- (IBAction)save:(id)sender;

- (void)insertField:(NSDictionary*)dict format:(NSMutableString*)formatStr 
			key:(NSString*)key par:(NSString*)par hash:(NSString*)hash;
@end
