/*
	Copyright 2008 Adriaan Tijsseling, All rights reserved.
	iTunes addon for ecto. 
*/
#import "Tunes.h"

@implementation NSMutableString (Utils)

// removes substring marked with hashes, as in "#p artist is ^p #p"
- (void)stripHashes:(NSString*)hash
{
	NSScanner		*scanner;
	BOOL			found = NO, done = NO;
	unsigned int	ixRight, ixLeft = 0, newLoc = 0;

	while ( !done )
	{
		scanner = [NSScanner scannerWithString:self];
		[scanner setCharactersToBeSkipped:nil];
		[scanner setScanLocation:newLoc];

		found = NO;
		if ( [scanner scanString:hash intoString:nil] || [scanner scanUpToString:hash intoString:nil] )
		{
			ixLeft = [scanner scanLocation];
			found = YES;
		}
		
		if ( [scanner isAtEnd] ) break;
		
		newLoc = [scanner scanLocation]+1;
		if ( found && ![scanner isAtEnd] )
		{
			[scanner setScanLocation:newLoc];
			found = [scanner scanUpToString:hash intoString:nil];
			if ( found && ![scanner isAtEnd] )
			{
				ixRight = [scanner scanLocation]+2;
				[self deleteCharactersInRange:NSMakeRange(ixLeft,ixRight-ixLeft)];
				newLoc = 0;
			}
		}
			
		done = [scanner isAtEnd];
	}
// remove any remaining hashes
	[self replaceOccurrencesOfString:hash withString:@"" options:0 range:NSMakeRange(0, [self length])];
}

@end

@implementation Tunes

- (id)init
{
	self = [super init];
	if ( self )
	{
		static BOOL uiLoaded = NO;
		if ( !uiLoaded )
		{
			if ( ![NSBundle loadNibNamed:@"AddonPrefs" owner:self] )
			{
				NSLog(@"Malformed nib file.");
				return nil;
			}
			uiLoaded = YES;
		}
	}	
	return self;
}

- (void)awakeFromNib
{
	// If I had something more to configure after the nib is loaded, I'd do it here.
}

- (void)dealloc
{
	// If I had allocated something in this class, I'd make sure it's released when this object dies
	[super dealloc];
}

// Your plugin's key. Make it unique. Functions as menu title.
- (NSString*)addonKey
{
	return @"iTunes";
}

// Your plugin's roles. Currently only addon or notifier. Can be both (ROLE_ADDON | ROLE_NOTIFIER, for example)
- (int)role
{
	return ROLE_ADDON;
}

// Toolbar icon path (nil if not applicable)
- (NSString*)toolbarIcon
{
	NSBundle *thisBundle = [NSBundle bundleForClass:[self class]];
	return [thisBundle pathForResource:@"itunes" ofType:@"tif"];
}

// Your plugin's description. Explain what it does. Will be shown to users in plugins list.
- (NSString*)addonDescription
{
	return NSLocalizedStringFromTable(
	@"This addon inserts currently playing songs from iTunes.", @"Tunes", @"Description");
}

// Addons can specify more actions, they'll go in a submenu. Return nil if there's only one action
// Note: Addons with subactions cannot have a toolbar icon
- (NSArray*)subActions
{
	return nil;
}

// If your addon requires the full text of an edit area to work on, return YES
- (BOOL)requiresFullText
{
	return NO;
}

// Preferences view
- (id)preferencesView
{
	[self revert:nil];
	return prefsView;
}

- (IBAction)revert:(id)sender
{
#pragma unused(sender)
	id	values = [[NSUserDefaultsController sharedUserDefaultsController] values];
	if ( [values valueForKey:@"tunes_format"] == nil )
	{
		[textView setString:@"<div class=\"itunes_track\">Listened to: <span class=\"title\">^t</span>#a from the album \"<span class=\"album\">^a</span>\"#a#p by <span class=\"artist\"><a href=\"http://www.google.com/search?q=%22^p%22\">^p</a></span></div>#p"];
	}
	else
	{
		[textView setString:[values valueForKey:@"tunes_format"]];
	}
}

- (IBAction)save:(id)sender
{
#pragma unused(sender)
	id	values = [[NSUserDefaultsController sharedUserDefaultsController] values];
	[values setValue:[textView string] forKey:@"tunes_format"];
}

/* The main routine. ecto calls the addon with selected text or full text (only from active text area), and delegate.
   Once done, call the delegate with selector 'addonFinished' and a string (return nil to cancel). 
   All text should be plain text (in HTML or any of the supported formats).
   If you require feedback from the user, return an object that 
   instantiates a nib and responds to @selector(view) to return a view for display.
   If you return an object, the delegate will keep it around for as long the delegate
   is alive, and send any following addonRequested calls directly to the object. 
   There is no need to manage objects you return. The delegate will release when done.
   Just make sure not to autorelease it. 
*/
- (id)addonRequested:(id)delegate selection:(NSString*)selectedText subaction:(NSString*)subaction
{
#pragma unused(selectedText, subaction)
	BOOL	isRunning = NO;
	int		i;
	NSArray *apps = [[ NSWorkspace sharedWorkspace] launchedApplications];
	for ( i = 0; i < [apps count]; i++ )
	{
		if ( [[[apps objectAtIndex:i] objectForKey:@"NSApplicationName"] isEqualToString:@"iTunes"] )
		{
			isRunning = YES;
			break;
		}
	}
	if ( isRunning == NO ) return nil;
	
	
	NSAutoreleasePool		*pool = [[NSAutoreleasePool alloc] init];
	NSBundle				*thisBundle = [NSBundle bundleForClass:[Tunes class]];
	NSString				*path = [thisBundle pathForResource:@"kungtunes" ofType:@"applescript"];
	NSString				*scriptFile = [[NSString alloc] initWithContentsOfFile:path];
	NSAppleScript			*insertField = [[NSAppleScript alloc] initWithSource:scriptFile];
	id						values = [[NSUserDefaultsController sharedUserDefaultsController] values];
	NSMutableString			*formatStr = nil;
	NSAppleEventDescriptor  *result;
	NSDictionary			*dict = nil;
	NSMutableDictionary		*trackDict;
	NSArray					*trackArray;
	
	result = [insertField executeAndReturnError:&dict];
	if ( dict != nil ) 
	{
		NSLog( @"%@", [dict description] );
	}
	[insertField release];
	[scriptFile release];

	if ( result == nil || [[result stringValue] isEqualToString:@"ERROR"] )
	{
		NSLog(@"iTunes is not playing!");
		return nil;
	}
	
	NSString *scriptResult = [result stringValue];
	trackArray = [scriptResult componentsSeparatedByString:@"\t"];
	trackDict = [[NSMutableDictionary alloc] init];
	for ( i = 0; i < [trackArray count]; i = i+2 )
	{
		[trackDict setObject:[trackArray objectAtIndex:i+1] forKey:[trackArray objectAtIndex:i]];
	}

	if ( [trackDict objectForKey:@"track"] != nil )
	{
		if ( [values valueForKey:@"tunes_format"] == nil )
		{
			formatStr = [[NSMutableString alloc] initWithString:
				@"<div class=\"itunes_track\">Listened to: <span class=\"title\">^t</span>#a from the album \"<span class=\"album\">^a</span>\"#a#p by <span class=\"artist\"><a href=\"http://www.google.com/search?q=%22^p%22\">^p</a></span></div>#p"];
		}
		else
			formatStr = [[NSMutableString alloc] initWithString:[values valueForKey:@"tunes_format"]];

	// put some stuff in it
	// trackname
		[formatStr replaceOccurrencesOfString:@"^t" withString:[trackDict objectForKey:@"track"] 
			options:0 range:NSMakeRange(0, [formatStr length])];
	// tracklength
		[self insertField:trackDict format:formatStr key:@"time" par:@"^l" hash:@"#l"];
	// album
		[self insertField:trackDict format:formatStr key:@"album" par:@"^a" hash:@"#a"];
	// artist
		[self insertField:trackDict format:formatStr key:@"artist" par:@"^p" hash:@"#p"];
	// composer
		[self insertField:trackDict format:formatStr key:@"composer" par:@"^w" hash:@"#w"];
	// year
		[self insertField:trackDict format:formatStr key:@"year" par:@"^y" hash:@"#y"];
	// genre
		[self insertField:trackDict format:formatStr key:@"genre" par:@"^g" hash:@"#g"];
	// rating
		[self insertField:trackDict format:formatStr key:@"rating" par:@"^r" hash:@"#r"];
	// count
		[self insertField:trackDict format:formatStr key:@"count" par:@"^c" hash:@"#c"];
	// comment
		[self insertField:trackDict format:formatStr key:@"comment" par:@"^k" hash:@"#k"];
	// url
		[self insertField:trackDict format:formatStr key:@"url" par:@"^u" hash:@"#u"];

	}
	else
		NSLog(@"iTunes is not playing!");

	[delegate performSelector:@selector(addonFinished:) withObject:formatStr];

	[trackDict release];
	[formatStr release];
	[pool release];
	return nil;
}

- (void)insertField:(NSDictionary*)dict format:(NSMutableString*)formatStr 
			key:(NSString*)key par:(NSString*)par hash:(NSString*)hash
{
	if ( [dict objectForKey:key] != nil && [(NSString*)[dict objectForKey:key] length] > 0 )
	{
		[formatStr replaceOccurrencesOfString:par withString:[dict objectForKey:key] 
			options:0 range:NSMakeRange(0, [formatStr length])];
		[formatStr replaceOccurrencesOfString:hash withString:@"" 
			options:0 range:NSMakeRange(0, [formatStr length])];
	}
	else
		[formatStr stripHashes:hash];
}

/* This routine is called when there is something to notify
   (entry posted, account refreshed, entries retrieved, categories updated, file uploaded)
   data passed along varies per notification type.
*/
- (void)processNotification:(int)type data:(id)data
{
#pragma unused(type, data)
}

@end
