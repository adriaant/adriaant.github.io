/*
	Protocol for an ecto addon. These methods should be implemented by the plugin.
	Currently, addons can have the following roles:
	1) Manipulating entry text, implement:
		- (NSString*)toolbarIcon;
		- (NSArray*)subActions;
		- (BOOL)requiresFullText;
		- (id)addonRequested:(id)delegate selection:(NSString*)selectedText subaction:(NSString*)subaction;
	2) Notifying after a succesful action
		- (void)processNotification:(int)type data:(id)data;

	To save defaults, use the NSUserDefaultsController. Prefix your defaults with your plugin name. i.e.
	myplugin_someSetting
*/

#import <Cocoa/Cocoa.h>

enum 
{
	ENTRY_POSTED_NOTE = 0,
	ACCOUNT_UPDATED_NOTE,
	ENTRIES_RETRIEVED_NOTE,
	CATEGORIES_UPDATED_NOTE,
	FILE_UPLOADED_NOTE
};

enum
{
	ROLE_ADDON = 1,
	ROLE_NOTIFIER = 2
};

@protocol ECTOAddonProtocol

// Your plugin's key. Make it unique. It will be a menu title, as well.
- (NSString*)addonKey;

// Your plugin's roles. Currently only addon or notifier. Can be both (ROLE_ADDON | ROLE_NOTIFIER, for example)
- (int)role;

// Your plugin's description. Explain what it does. Will be shown to users in plugins list.
- (NSString*)addonDescription;

// Preferences view
- (id)preferencesView;

/*
	NOTIFIER
*/

/* This routine is called when there is something to notify
   (entry posted, account refreshed, entries retrieved, categories updated, file uploaded)
   data passed along varies per notification type.
*/
- (void)processNotification:(int)type data:(id)data;

/*
	TEXT MANIPULATOR
*/

// Toolbar icon path (nil if not applicable)
- (NSString*)toolbarIcon;

// Addons can specify more actions, they'll go in a submenu. Return nil if there's only one action
// Note: Addons with sub actions cannot have a toolbaricon
- (NSArray*)subActions;

// If your addon requires the full text of an edit area to work on, return YES
- (BOOL)requiresFullText;

/* The main routine. ecto calls the addon with selected text, 
   full text (only from active text area), and delegate.
   Once done, call the delegate with selector 'addonFinished' and a string (return nil to cancel). 
   All text should be plain text (in HTML or any of the supported formats).
   If you require feedback from the user, return an object that 
   instantiates a nib and responds to @selector(view) to return a view for display.
   If you return an object, the delegate will keep it around for as long the delegate
   is alive, and send any following addonRequested calls directly to the object. 
   There is no need to manage objects you return. The delegate will release when done.
   Just make sure not to autorelease it. 
*/
- (id)addonRequested:(id)delegate selection:(NSString*)selectedText subaction:(NSString*)subaction;

@end
