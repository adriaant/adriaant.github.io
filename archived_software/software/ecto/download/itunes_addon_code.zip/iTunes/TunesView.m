#import "TunesView.h"

@implementation TunesView

- (void)drawRect:(NSRect)rect
{
	[[NSColor colorWithDeviceWhite:0.98 alpha:1] set];
	NSRectFill(rect);
}

@end
