/*
	Created by Adriaan Tijsseling on 07/14/07.
	Copyright 2007 Adriaan Tijsseling, All rights reserved.

	Twitter addon for ecto. 
*/

#import <Cocoa/Cocoa.h>
#import "AddonInterface.h"

@interface Twitter : NSObject <ECTOAddonProtocol>
{
	IBOutlet id prefsView;
}

- (IBAction)help:(id)sender;

@end
