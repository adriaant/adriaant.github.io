/*
	Created by Adriaan Tijsseling on 07/14/07.
	Copyright 2007 Adriaan Tijsseling, All rights reserved.

	Twitter notifier for ecto. 
*/

#import "Twitter.h"

@implementation Twitter

// Basic initialization. You can use this as is. 
- (id)init
{
	self = [super init];
	if ( self )
	{
		static BOOL uiLoaded = NO;
	// load nib
		if ( !uiLoaded )
		{
			if ( ![NSBundle loadNibNamed:@"AddonPrefs" owner:self] )
			{
				NSLog(@"Malformed nib file.");
				return nil;
			}
			uiLoaded = YES;
		}
	}	
	return self;
}

- (void)awakeFromNib
{
// if you need to set up stuff once the nib has loaded, you'd do that here.
}

// Your plugin's key. Make it unique. Functions as menu title. 
// REQUIRED
- (NSString*)addonKey
{
	return @"Twitter";
}

// Your plugin's roles. Currently only addon or notifier. 
// Can be both (ROLE_ADDON | ROLE_NOTIFIER, for example)
// REQUIRED
- (int)role
{
	return ROLE_NOTIFIER;
}

// Toolbar icon path (nil if not applicable. NOTE: does not apply to notifier-role addons)
// REQUIRED
- (NSString*)toolbarIcon
{
	return nil;
}

// Your plugin's description. Explain what it does. Will be shown to users in plugins list.
// REQUIRED
- (NSString*)addonDescription
{
	return NSLocalizedString(
	@"This addon lets you post a tweet to your twitter account after posting a new blog post.", @"Description");
}

// Addons can specify more actions, they'll go in a submenu. Return nil if there's only one action
// NOTE: Addons with sub actions cannot have a toolbar icon
// NOTE: Does not apply to notifier-role addons
- (NSArray*)subActions
{
	return nil;
}

// If your addon requires the full text of an edit area to work on, return YES
// NOTE: Does not apply to notifier-role addons
- (BOOL)requiresFullText
{
	return NO;
}

// Preferences view. Return nil if your addon does not need configuration from the user
// REQUIRED
- (id)preferencesView
{	
	return prefsView;
}

/* The main routine. ecto calls the addon with selected text, 
   full text (only from active text area), and delegate.
   Once done, call the delegate with selector 'addonFinished' and a string (return nil to cancel). 
   All text should be plain text (in HTML or any of the supported formats).
   If you require feedback from the user, return an object that 
   instantiates a nib and responds to @selector(view) to return a view for display.
   If you return an object, the delegate will keep it around for as long the delegate
   is alive, and send any following addonRequested calls directly to the object. 
   There is no need to manage objects you return. The delegate will release when done.
   Just make sure not to autorelease it. 
*/
// NOTE: Does not apply to notifier-role addons
- (id)addonRequested:(id)delegate selection:(NSString*)selectedText subaction:(NSString*)subaction
{
#pragma unused(delegate,selectedText,subaction)
	return nil;
}

/* This routine is called when there is something to notify
   (entry posted, account refreshed, entries retrieved, categories updated, file uploaded)
   data passed along varies per notification type. Example:
	
	if ( type == ENTRY_POSTED_NOTE )
	{
		title = [data objectForKey:@"blogtitle"];
		desc = [NSString localizedStringWithFormat:NSLocalizedString(
					@"\"%@\" was successfully published!", @"Posted notification"), [data objectForKey:@"title"]];
		url = [data objectForKey:@"permaLink"];
	}
	else if ( type == ENTRIES_RETRIEVED_NOTE )
	{
		title = (NSString*)data; // blog name
		desc = NSLocalizedString(@"Blog posts retrieved!", @"Notification");
	}
	else if ( type == ACCOUNT_UPDATED_NOTE )
	{
		title = (NSString*)data; // account name
		desc = NSLocalizedString(@"Account updated!", @"Notification");
	}
	else if ( type == CATEGORIES_UPDATED_NOTE )
	{
		title = (NSString*)data; // blog name
		desc = NSLocalizedString(@"Categories retrieved!", @"Notification");
	}
	else if ( type == FILE_UPLOADED_NOTE )
	{
		title = (NSString*)data; // filename
		desc = NSLocalizedString(@"File successfully uploaded!", @"Notification");
	}
*/

- (void)processNotification:(int)type data:(id)data
{
	if ( type == ENTRY_POSTED_NOTE )
	{
		// these are values set in our preferences pane
		id values = [[NSUserDefaultsController sharedUserDefaultsController] values];
		NSString *user = [values valueForKey:@"twitter_user"];
		NSString *pass = [values valueForKey:@"twitter_pass"];
		
		if ( user != nil && pass != nil )
		{
		// a entry posted notification will give us the entry's data. To see what it contains, just
		// do an NSLog with the data's description. Here, we first check "isAnEdit" and bail if it's true,
		// since that means the user posted an edit of a previously published entry and we don't want to
		// spam twitter for each edit
			NSDictionary	*entryData = (NSDictionary*)data;
			NSNumber		*edited = [entryData objectForKey:@"isAnEdit"];
			
			// this is pretty hacky, but it's solid and works
			if ( edited == nil || ![edited boolValue] )
			{
				NSMutableString	*statusStr = [NSMutableString stringWithString:@"status="];
				NSString		*url = [entryData objectForKey:@"permaLink"];
				NSString		*title = [entryData objectForKey:@"title"];
				NSString		*tmplt = [values valueForKey:@"twitter_tmpl"];
				
				if ( tmplt == nil || [tmplt length] < 4 ) tmplt = @"New blog post at $url$"; // default template
				[statusStr appendString:tmplt];
				
				[statusStr replaceOccurrencesOfString:@"$url$" withString:url options:0 range:NSMakeRange(0,[statusStr length])];
				[statusStr replaceOccurrencesOfString:@"$title$" withString:title options:0 range:NSMakeRange(0,[statusStr length])];

				NSString *escUser = (NSString*)CFURLCreateStringByAddingPercentEscapes(NULL, (CFStringRef)user, NULL, (CFStringRef)@";/?:@&=+$,", kCFStringEncodingUTF8);
				NSString *escPass = (NSString*)CFURLCreateStringByAddingPercentEscapes(NULL, (CFStringRef)pass, NULL, (CFStringRef)@";/?:@&=+$,", kCFStringEncodingUTF8);
				NSString *escUrl  = [[NSString alloc] initWithFormat:@"http://%@:%@@twitter.com/statuses/update.xml", escUser, escPass];
				NSURL	 *twitterUrl = [NSURL URLWithString:escUrl];
				
				[escUser release];
				[escPass release];
				
				NSMutableURLRequest *urlRequest = [NSMutableURLRequest requestWithURL:twitterUrl];
				// always set a user-agent, it's polite
				[urlRequest setValue:@"ecto (http://infinite-sushi.com/software/ecto, MacOSX)" forHTTPHeaderField:@"User-Agent"];
				[urlRequest setHTTPMethod:@"POST"];
				[urlRequest setHTTPBody:[statusStr dataUsingEncoding:NSUTF8StringEncoding]];

				NSURLResponse	*response = nil;
				NSData			*retVal = [NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&response error:NULL];
				int				statusCode = [(NSHTTPURLResponse*)response statusCode];
				NSString		*errorStr = nil;
				
				// simple error checks
				if ( statusCode == 401 )
					errorStr = @"It doesn't look like your username and password are correct.";
				else if ( statusCode > 400 )
					errorStr = [NSString stringWithFormat:@"Twitter didn't accept the tweet (%d).", statusCode];
				
				[escUrl release];
				if ( errorStr != nil )
				{
					NSRunCriticalAlertPanel(@"Tweet failed!", errorStr, @"Bah", nil, nil);
				}
				else
				{
					BOOL	 success = NO;
					// twitter uses utf8 like a good boy, so we assume this encoding
					NSString *retStr = [[NSString alloc] initWithData:retVal encoding:NSUTF8StringEncoding];
					if (retStr != nil )
					{
						NSString	*tweetID = nil;
						NSString	*screen = nil;
						
						// Yes, I'm using rangeOfString to parse the XML. Woe is me. 
						NSRange rng1 = [retStr rangeOfString:@"<id>"];
						NSRange rng2 = [retStr rangeOfString:@"</id>"];
						if ( rng1.length > 0 && rng2.length > 0 )
						{
							int start = rng1.location+rng1.length;
							int len = rng2.location - start;
							NSRange rng3 = NSMakeRange(start,len);
							tweetID = [retStr substringWithRange:rng3];
						}

						rng1 = [retStr rangeOfString:@"<screen_name>"];
						rng2 = [retStr rangeOfString:@"</screen_name>"];
						if ( rng1.length > 0 && rng2.length > 0 )
						{
							int start = rng1.location+rng1.length;
							int len = rng2.location - start;
							NSRange rng3 = NSMakeRange(start,len);
							screen = [retStr substringWithRange:rng3];
						}
						
						[retStr release];

						// we got what we wanted, let's show the user the new tweet
						if ( tweetID != nil && screen != nil )
						{
							NSString *tweetURL = [NSString stringWithFormat:@"http://twitter.com/%@/statuses/%@", screen, tweetID];
							[[NSWorkspace sharedWorkspace] openURL:[NSURL URLWithString:tweetURL]];
							success = YES;
						}
					}
					if ( !success )
						// Oh noes!
						NSRunCriticalAlertPanel(@"Tweet failed!", @"For unknown reasons the tweet did not make it on the Twitter site.", @"Bah", nil, nil);
				}
			}
		}
	}
}

// called from button in preferences pane. Explains the user how to configure. 
- (IBAction)help:(id)sender
{
#pragma unused(sender)
	NSBundle *thisBundle = [NSBundle bundleForClass:[self class]];
	NSString *path = [thisBundle pathForResource:@"index" ofType:@"html"];
	if ( path != nil )
	{
		NSURL *url = [NSURL fileURLWithPath:path];
		if ( url != nil )
			[[NSWorkspace sharedWorkspace] openURL:url];
	}
}

@end
