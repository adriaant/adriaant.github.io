/*
	Copyright 2007 Adriaan Tijsseling, All rights reserved.
	Sample uploader for ecto. 
*/

#import <Cocoa/Cocoa.h>
#import "UploaderInterface.h"

@class SUUploadWorker;

@interface SampleUploader : NSObject <ECTOUploaderProtocol>
{
	NSNib			*uploaderNib;	
	SUUploadWorker	*uploadWorker;
	id				delegate;
	SEL				errorSelector;
	SEL				endSelector;
	SEL				statusSelector;
}

- (void)setStatus:(NSString*)status;
- (void)uploadFailed:(NSString*)error;
- (void)uploadSucceeded:(NSDictionary*)dict;
- (void)cancel;

@end
