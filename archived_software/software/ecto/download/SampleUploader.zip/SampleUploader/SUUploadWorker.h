/*
	Copyright 2007 Adriaan Tijsseling, All rights reserved.
	Sample uploader for ecto. 
*/

#import <Cocoa/Cocoa.h>

@interface SUUploadWorker : NSObject
{
	id					_delegate;
	NSMutableDictionary	*_uploadItem;
}

- (id)initWithData:(NSDictionary*)data delegate:(id)del;

- (void)upload;

- (void)setStatus:(NSString*)status;

@end
