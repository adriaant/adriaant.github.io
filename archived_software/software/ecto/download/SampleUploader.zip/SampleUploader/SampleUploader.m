/*
	Copyright 2007 Adriaan Tijsseling, All rights reserved.
	Sample uploader for ecto. 
*/

#import "SampleUploader.h"
#import "SampleUploaderSettings.h"
#import "SUUploadWorker.h"

@implementation SampleUploader

- (id)init
{
	self = [super init];
	if ( self )
	{
		uploadWorker = nil;
	}	
	return self;
}

- (void)dealloc
{
	[uploadWorker release];
	[uploaderNib release];
	[super dealloc];
}

// Your plugin's key. Make it unique. Functions as menu title.
- (NSString*)uploaderKey
{
	return @"SampleUploader";
}

// Your plugin's description. Explain what it does. Will be shown to users in plugins list.
- (NSString*)uploaderDescription
{
	return NSLocalizedString(
	@"This is a demonstration uploader that actually does not upload.", @"Description");
}

// If your uploader allows the user to specify a destination path, return YES
- (BOOL)canSpecifyDestinationPath
{
	return NO;
}

/* The main routine. ecto calls the uploader with attachment settings.
   The settings are in an NSMutableDictionary, reserved for uploaders. Set values using keys prefixed
   with a unique key to avoid conflicts with other uploaders.
   Return an object that instantiates a nib and responds to @selector(view) to provide a view for display.
   ecto will keep the object around for as long it is in use. 
   There is no need to manage objects you return. ecto will release when done.
*/
- (id)uploaderRequested:(NSMutableDictionary*)settings
{
	if ( uploaderNib == nil )
	{
		uploaderNib = [[NSNib alloc] initWithNibNamed:@"SampleUploader" bundle:[NSBundle bundleForClass:[self class]]];
	}
	if ( uploaderNib != nil )
	{
		SampleUploaderSettings *obj = [[SampleUploaderSettings alloc] initWithNib:uploaderNib settings:settings];
		return obj;
	}
	return nil;
}

/* The call to upload a file. You will receive a dictionary with keys:
	name: name of file
	type: type of file
	bits: data of file
	
	if it involves an image, you'll also get:
	width: desired width of image (image is already resized for this)
	height: desired height of image
	
	thumbbits: data of thumbnail image, nil if user does not desire thumbnail
	thumbname: name of thumbnail
	thumbwidth: desired width of thumbnail (thumbnail image is already resized for this)
	thumbheight: desired height of thumbnail

	as well as any of your settings.
	
	You are responsible for releasing the 'data' dictionary.
	
	On succes, send a dictionary with at least key 'url' for NSString with url of uploaded file to the endSelector.
	On error, send a string to the errorSelector.
	For displaying statuses to the user, send strings to statusSelector.
*/
- (void)uploadData:(NSDictionary*)data delegate:(id)del errorSelector:(SEL)err endSelector:(SEL)end statusSelector:(SEL)stat
{
	if ( uploadWorker != nil )
	{
		[data release];
		[del performSelector:err withObject:NSLocalizedString(@"You are already uploading a file, please wait for that to complete before uploading another file", @"Overload error")];
	}
	else
	{
		errorSelector  = err;
		endSelector	   = end;
		statusSelector = stat;
		delegate       = del;
		
		NSString *type = [data objectForKey:@"type"];
		if ( type == nil || ![type hasPrefix:@"image"] )
		{
			[data release];
			[delegate performSelector:errorSelector withObject:NSLocalizedString(@"This sample only allows image uploads!", @"Type error")];
		}
		else
		{
			uploadWorker = [[SUUploadWorker alloc] initWithData:data delegate:self];
			if ( uploadWorker == nil )
			{
				[data release];
				[delegate performSelector:errorSelector withObject:NSLocalizedString(@"Could not allocate uploader object. Seriously, wtf?", @"Allocate error")];
			}
			else
			{
				[uploadWorker upload];
			}
		}
	}
}

- (void)setStatus:(NSString*)status
{
	if ( delegate != nil && [delegate respondsToSelector:statusSelector] )
		[delegate performSelector:statusSelector withObject:status];
}

- (void)uploadFailed:(NSString*)error
{
	if ( delegate != nil && [delegate respondsToSelector:errorSelector] )
		[delegate performSelector:errorSelector withObject:error];
	[uploadWorker release], uploadWorker = nil;
}

- (void)uploadSucceeded:(NSDictionary*)dict
{
	NSDictionary *response = [dict copy];
	[uploadWorker release];
	uploadWorker = nil;
	if ( delegate != nil && [delegate respondsToSelector:endSelector] )
		[delegate performSelector:endSelector withObject:response];
}

/* The cancel method is required for users to allow cancelling uploads. It is invoked by ecto.
   On cancel, simply stop what you're doing and return control to the delegate via the error selector
*/
- (void)cancel
{
	[self uploadFailed:nil]; // pass nil as argument since it's a user-initiated action
}

@end
