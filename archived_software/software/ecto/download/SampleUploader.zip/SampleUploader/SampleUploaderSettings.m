/*
	Copyright 2007 Adriaan Tijsseling, All rights reserved.
	Sample uploader for ecto. 
*/

#import "SampleUploaderSettings.h"
#import "SampleUploader.h"

@implementation SampleUploaderSettings

- (id)initWithNib:(NSNib*)nib settings:(NSMutableDictionary*)dict
{
	self = [super init];
	if ( self )
	{
		settings = [dict retain];
		[nib instantiateNibWithOwner:self topLevelObjects:nil];
	}
	return self;
}

- (void)willDispose:(id)sender
{
#pragma unused(sender)
// always set the object controller's content to nil or we have leaks
	[objController setContent:nil];
}

- (void)dealloc
{
	[settings release];
	[sampleString release];
	[super dealloc];
}

- (void)awakeFromNib
{
// nothing to do here in this sample
}

- (id)view
{
	return view;
}

- (void)setSettings:(NSMutableDictionary*)dict
{
	[dict retain];
	[settings release];
	settings = dict;
}

// A sample setting. Note that it's stored inside the settings dictionary
// passed on to us by ecto.
- (NSString*)sampleString
{
	if ( sampleString == nil )
	{
		if ( [settings objectForKey:@"susample_string"] != nil )
			sampleString = [[settings objectForKey:@"susample_string"] mutableCopy];
		else
			sampleString = [[NSString alloc] initWithString:@"Hello!"];
	}
	return sampleString;
}
- (void)setSampleString:(NSString*)str
{
	[self willChangeValueForKey:@"sampleString"];
	[sampleString release];
	if ( str == nil )
	{
		sampleString = nil;
		[settings removeObjectForKey:@"susample_string"];
	}
	else
	{
		sampleString = [str copy];
		[settings setObject:sampleString forKey:@"susample_string"];
	}
	[self didChangeValueForKey:@"sampleString"];
}

@end
