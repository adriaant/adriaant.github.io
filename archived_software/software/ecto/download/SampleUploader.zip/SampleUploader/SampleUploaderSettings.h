/*
	Copyright 2007 Adriaan Tijsseling, All rights reserved.
	Sample uploader for ecto. 
*/

#import <Cocoa/Cocoa.h>

@interface SampleUploaderSettings : NSObject
{
	NSMutableDictionary	*settings;
	
	IBOutlet NSView		*view;
	IBOutlet id			objController;
	
	NSString			*sampleString;
}

- (id)initWithNib:(NSNib*)nib settings:(NSMutableDictionary*)dict;
- (void)willDispose:(id)sender;

- (id)view;
- (void)setSettings:(NSMutableDictionary*)dict;

@end
