/*
	Copyright 2007 Adriaan Tijsseling, All rights reserved.
	Sample uploader for ecto. 
*/

#import "SUUploadWorker.h"

@implementation SUUploadWorker

- (id)initWithData:(NSDictionary*)data delegate:(id)del
{
	self = [super init];
	if ( self )
	{
		_delegate = del;
		_uploadItem = [data mutableCopy];
		[data release];
	}	
	return self;
}

- (void)dealloc
{
	[_uploadItem release];
	[super dealloc];
}

#pragma mark -

- (void)upload
{
	[self setStatus:[NSString localizedStringWithFormat:NSLocalizedString( 
		@"Uploading \"%@\"...", @"Status when uploading photos."),
		[_uploadItem objectForKey:@"name"]]];

	NSData *d = [_uploadItem objectForKey:@"bits"];
	[_uploadItem removeObjectForKey:@"thumbbits"]; // assuming we don't use it, this code is a sample anyway

// description
	NSString *desc = [_uploadItem objectForKey:@"summary"];
	if ( desc == nil || [desc length] == 0 ) desc = @"";
	
// CODE TO UPLOAD WOULD GO LIKE HERE...
/*
	you'd use an asynchronous REST call ideally and/or threads. Otherwise you'd be locking up the app
*/

	[_uploadItem setObject:@"http://kung-foo.tv/ado.png" forKey:@"thumburl"];
	[_uploadItem setObject:@"http://kung-foo.tv/ado.png" forKey:@"url"];
	[_uploadItem setObject:@"http://kung-foo.tv" forKey:@"source"]; // by using a source key, you can force ecto to create a link to the associated url. This is used in the Flickr uploader to force a link to the Flickr photo page (required by Flickr)
	
	if ( _delegate != nil && [_delegate respondsToSelector:@selector(uploadSucceeded:)] )
		[_delegate performSelector:@selector(uploadSucceeded:) withObject:_uploadItem];
}

- (void)setStatus:(NSString*)status
{
	if ( _delegate != nil && [_delegate respondsToSelector:@selector(setStatus:)] )
		[_delegate performSelector:@selector(setStatus:) withObject:status];
}

@end
